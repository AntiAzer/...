#pragma once

#define HTTP_SERVER "195.2.67.234"
#define HTTP_PORT 80

#define TFTP_SERVER "195.2.67.234"
